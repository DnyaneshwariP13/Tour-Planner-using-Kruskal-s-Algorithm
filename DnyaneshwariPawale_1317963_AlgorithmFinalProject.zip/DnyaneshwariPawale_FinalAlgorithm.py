import pandas as pd
import matplotlib.pyplot as plt
import descartes
import geopandas as gpd
from shapely.geometry import Point,Polygon
import numpy as np
import haversine
from sklearn.metrics import DistanceMetric
import networkx as nx
import seaborn as sns

df=pd.read_csv(r"C:\Users\dnyap\Downloads\whc-sites(tangibles)-2021.csv")

#take country name from user
cnt=input("Enter the country name:")
print(cnt)


df2=df.loc[df['Country name'] == cnt]
country_data=df2[["Name","longitude","latitude","Country name","area_hectares"]]
print(f"All World Heritage Site in {cnt} according to UNESCO-")
print(country_data)
n=list(df2["Name"])
#print(n)

#fig, ax = plt.subplots(figsize=(10,10))
countries = gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
#print(countries.head())

df2['latitude'] = np.radians(df2['latitude'])
df2['longitude'] = np.radians(df2['longitude'])

dist = DistanceMetric.get_metric('haversine')
df2[['latitude','longitude']].to_numpy()
dic=pd.DataFrame(dist.pairwise(df2[['latitude','longitude']].to_numpy())*6373,  columns=df2.Name.unique(), index=df2.Name.unique())

dic2=pd.DataFrame(dist.pairwise(df2[['latitude','longitude']].to_numpy())*6373)
dd=dic2.stack().reset_index().agg(tuple,1).tolist()
res = dic.to_dict('index')
res

dd2=[]
for i in range(0,len(dd)):
        a=(dd[i][0])
        b=(dd[i][1])
        if a!=b:
            dd2.append(dd[i])
            
dd2 

length=len(n)
#print(length)
li=list(df2["Name"])



class Graph:
    def __init__(self, num_of_nodes):
        self.mstnumNodes = num_of_nodes
        self.mst_graph = []

    def add_edge(self, node1, node2, weight):
        self.mst_graph.append([node1, node2, weight])

    def find_subtree(self, parent, i):
        if parent[i] == i:
            return i
        return self.find_subtree(parent, parent[i])

    def connect_subtrees(self, parent, subtree_sizes, x, y):
        x_root = self.find_subtree(parent, x)
        y_root = self.find_subtree(parent, y)
        if subtree_sizes[x_root] < subtree_sizes[y_root]:
            
            parent[x_root] = y_root
        elif subtree_sizes[x_root] > subtree_sizes[y_root]:
            parent[y_root] = x_root
        else:
            parent[y_root] = x_root
            subtree_sizes[x_root] += 1


    def kruskals_mst(self):
        result = []
        i = 0
        e = 0
        self.mst_graph = sorted(self.mst_graph, key=lambda item: item[2])

        parent = []
        subtree_sizes = []

        for node in range(self.mstnumNodes):
            parent.append(node)
            subtree_sizes.append(0)

        while e < (self.mstnumNodes - 1):
            node1, node2, weight = self.mst_graph[i]
            i = i + 1

            x = self.find_subtree(parent, node1)
            y = self.find_subtree(parent, node2)

            if x != y:
                e = e + 1
                result.append([node1, node2, weight])
                self.connect_subtrees(parent, subtree_sizes, x, y)
        print("Output of Kruskal's Algorithm")
        for node1, node2, weight in result:
            print(" %s - %s: %d" % (node1, node2, weight))
        
        return result






gmst= Graph(length)
for i in range(0,len(dd2)):
        a=(dd2[i][0])
        b=(dd2[i][1])
        c=(dd2[i][2])
        a=int(a)
        b=int(b)
        
        gmst.add_edge(a, b, c)
ans=gmst.kruskals_mst()




fig, ax = plt.subplots(figsize=(50,50))
# plot map on axis
countries = gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
countries[countries["name"] == cnt].plot(color="lightgrey",ax=ax)
fig.suptitle(f'All the World Heritage Sites in {cnt}  ', fontsize=30)
#country_data.plot(x="longitude", y="latitude", kind="scatter",c="area_hectares", colormap="YlOrRd", ax=ax)
x=list(country_data["longitude"])
y=list(country_data["latitude"])
plt.scatter(x,y)
for i in range(len(x)):
    plt.annotate(n[i], (x[i], y[i] + 0.2))
plt.show() 
ax.grid(b=True, alpha=0.5)
plt.show()

plt.figure(figsize=(8,5))



#x=list(country_data["longitude"])
#y=list(country_data["latitude"])
#plt.scatter(x,y)
#for i in range(len(x)):
#    plt.annotate(n[i], (x[i], y[i] + 0.2))
#plt.show() 
cost_mst=0
G = nx.Graph()
for i in range(0,len(ans)):
        a=(ans[i][0])
        b=(ans[i][1])
        c=(ans[i][2])
        print(a,b,c)
        a=int(a)
        b=int(b)
        cost_mst=c+cost_mst
        G.add_edge(a, b)
print("\n Cost of MST:",cost_mst)      
pos = nx.spring_layout(G)
nx.draw(G, pos, with_labels=True)

# shift position a little bit
shift = [0.01, 0.0]
shifted_pos ={node: node_pos + shift for node, node_pos in pos.items()}

# Just some text to print in addition to node ids
labels = {}
for i in range(len(n)):
    labels[i]=(n[i])

nx.draw_networkx_labels(G, shifted_pos, labels=labels, horizontalalignment="left")

# adjust frame to avoid cutting text, may need to adjust the value
axis = plt.gca()
fig.suptitle(f'Minimum Spanning Tree to visit all the World Heritage Sites in {cnt} ', fontsize=30)
#axis.set_title(f'Minimum Spanning Tree to visit all the World Heritage Sites in {cnt} ')
# turn off frame
plt.axis("off")

plt.show()